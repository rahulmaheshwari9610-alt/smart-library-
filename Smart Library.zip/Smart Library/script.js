// Book data stored locally (can be replaced with database later)
const books = [
    { name: "Java Programming", category: "Programming", img: "https://images.unsplash.com/photo-1512820790803-83ca734da794" },
    { name: "Python Basics", category: "Programming", img: "https://images.unsplash.com/photo-1516979187457-637abb4f9353" },
    { name: "Data Structures", category: "CS Core", img: "https://images.unsplash.com/photo-1507842217343-583bb7270b66" },
    { name: "Operating System", category: "CS Core", img: "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f" },
    { name: "Web Development", category: "Web", img: "https://images.unsplash.com/photo-1498050108023-c5249f4df085" },
    { name: "Cloud Computing", category: "Cloud", img: "https://images.unsplash.com/photo-1518770660439-4636190af475" }
];
// Fetch issued books from browser storage
let issuedBooks = JSON.parse(localStorage.getItem("issuedBooks")) || [];
// Display all books
function displayBooks(list) {
    const bookList = document.getElementById("bookList");
    bookList.innerHTML = "";
    list.forEach(book => {
        bookList.innerHTML += `
            <div class="book">
                <img src="${book.img}">
                <h3>${book.name}</h3>
                <p>Category: ${book.category}</p>
                <button onclick="issueBook(this, '${book.name}')">Issue Book</button>
            </div>
        `;
    });
}
// Issue book function
function issueBook(btn, name) {
    // Prevent duplicate issue
    if (issuedBooks.includes(name)) {
        alert("Book already issued");
        return;
    }
    // Limit of 5 books
    if (issuedBooks.length >= 5) {
        alert("You can issue only 5 books");
        return;
    }
    issuedBooks.push(name);
    localStorage.setItem("issuedBooks", JSON.stringify(issuedBooks));
    btn.innerText = "Issued ✔";
    btn.classList.add("issued");
    showIssued();
    showToast("Book Issued Successfully");
}
// Show issued books list
function showIssued() {
    const ul = document.getElementById("issuedList");
    ul.innerHTML = "";
    issuedBooks.forEach((book, index) => {
        ul.innerHTML += `
            <li>
                ${book}
                <button onclick="returnBook(${index})">Return</button>
            </li>
        `;
    });
}
// Return book
function returnBook(index) {
    issuedBooks.splice(index, 1);
    localStorage.setItem("issuedBooks", JSON.stringify(issuedBooks));
    showIssued();
    displayBooks(books);
}
// Search book by name
function searchBook() {
    const text = document.getElementById("search").value.toLowerCase();
    const filtered = books.filter(b => b.name.toLowerCase().includes(text));
    displayBooks(filtered);
}
// Filter by category
function filterCategory(category) {
    const filtered = books.filter(b => b.category === category);
    displayBooks(filtered);
}
// Simple toast message
function showToast(msg) {
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.innerText = msg;
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 2000);
}
// Initial load
displayBooks(books);
showIssued();
